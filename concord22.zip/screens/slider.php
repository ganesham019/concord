<div class="container bg-white pt-3 pb-3 pl-1 pr-1">
    <div class="carousel">

        <div class="card " style="margin:10px;">
            <img src="./assets/s1.jpg" class="card-img-top" alt="...">
        </div>

        <div class="card " style="margin:10px;">
            <img src="./assets/s1.jpg" class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="./assets/s1.jpg" class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="./assets/s1.jpg" class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="./assets/s1.jpg" class="card-img-top" alt="...">
        </div>

    </div>
</div>
</div>