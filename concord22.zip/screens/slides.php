<html>

<head>

    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />


</head>

<body>




    <div style="  " class="container-fluid mx-auto p-0 m-0 slidesbg">
        <div>
            <style>
            .swiper {
                /* height: 100vh; */
                padding: 40px 0px;
                width: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: #fff;
            }

            .swiper-slide {
                background-position: center;
                background-size: cover;
                width: 340px;
                height: 380px;
                background-color: transparent;
                opacity: 1;
                display: -webkit-box;
                display: -ms-flexbox;
                display: -webkit-flex;
                display: flex;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                -webkit-justify-content: center;
                justify-content: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                -webkit-align-items: center;
                align-items: center;
            }

            .swiper-slide img {
                display: block;
                width: 340px;
                height: 380px;
                opacity: 1;

            }
            </style>
            </head>


            <div style="" class="swiper mySwiper bg-white  slidesbg">
                <div class="swiper-wrapper">
                    <div class="swiper-slide s1">
                        <img style="width: 340px;
                       height: 380px; border-radius: 5px;" src="./assets/s1.jpg" />
                        <style>
                        .s1 {
                            position: relative;
                        }

                        .s1:hover .s1-1 {
                            visibility: visible;
                            opacity: 0.9;
                            width: 340px;
                            position: absolute;
                            bottom: 0;

                        }

                        .s1-1 {
                            opacity: 0;
                            transition: 0.3s;
                            position: absolute;
                            bottom: 0%;
                            border-bottom-left-radius: 5px;
                            border-bottom-right-radius: 5px;

                            width: 340px;
                            height: 300px;
                            visibility: hidden;
                        }

                        .bb2 {
                            position: absolute;
                            bottom: 30px;
                            left: 50%;
                        }
                        </style>
                        <div style="  " class="bb2">

                        </div>
                        <div class="s1-1">

                        </div>

                    </div>
                    <div class="swiper-slide s1">
                        <img style="width: 340px;
                       height: 380px; border-radius: 5px;" src="./assets/s1.jpg" />
                        <style>
                        .s1 {
                            position: relative;
                        }

                        .s1:hover .s1-1 {
                            visibility: visible;
                            opacity: 0.9;
                            position: absolute;
                            bottom: 0;

                        }

                        .s1-1 {
                            opacity: 0;
                            transition: 0.3s;
                            position: absolute;
                            bottom: 0%;
                            border-bottom-left-radius: 5px;
                            border-bottom-right-radius: 5px;

                            visibility: hidden;
                        }

                        .bb1 {
                            position: absolute;
                            bottom: 32px;
                            left: 50%;
                        }
                        </style>
                        <div style="  " class="bb1">

                        </div>
                        <div class="s1-1">

                        </div>

                    </div>
                    <div class="swiper-slide s1">
                        <img style="width: 340px;
                         height: 380px; border-radius: 5px;" src="./assets/s1.jpg" />
                        <style>
                        .s1 {
                            position: relative;
                        }

                        .s1:hover .s1-1 {
                            visibility: visible;
                            opacity: 0.9;
                            position: absolute;
                            bottom: 0;

                        }

                        .s1-1 {
                            opacity: 0;
                            transition: 0.3s;
                            position: absolute;
                            bottom: 0%;
                            border-bottom-left-radius: 5px;
                            border-bottom-right-radius: 5px;

                            visibility: hidden;
                        }

                        .bb1 {
                            position: absolute;
                            bottom: 32px;
                            left: 50%;
                        }
                        </style>
                        <div style="  " class="bb1">

                        </div>
                        <div class="s1-1">

                        </div>

                    </div>
                    <div class="swiper-slide s1">
                        <img style="width: 340px;
                         height: 380px; border-radius: 5px;" src="./assets/s1.jpg" />
                        <style>
                        .s1 {
                            position: relative;
                        }

                        .s1:hover .s1-1 {
                            visibility: visible;
                            opacity: 0.9;
                            position: absolute;
                            bottom: 0;

                        }

                        .s1-1 {
                            opacity: 0;
                            transition: 0.3s;
                            position: absolute;
                            bottom: 0%;
                            border-bottom-left-radius: 5px;
                            border-bottom-right-radius: 5px;

                            visibility: hidden;
                        }

                        .bb1 {
                            position: absolute;
                            bottom: 32px;
                            left: 50%;
                        }
                        </style>
                        <div style="  " class="bb1">

                        </div>
                        <div class="s1-1">

                        </div>

                    </div>
                    <div class="swiper-slide s1">
                        <img style="width: 340px;
                         height: 380px; border-radius: 5px;" src="./assets/s1.jpg" />
                        <style>
                        .s1 {
                            position: relative;
                        }

                        .s1:hover .s1-1 {
                            visibility: visible;
                            opacity: 0.9;
                            position: absolute;
                            bottom: 0;

                        }

                        .s1-1 {
                            opacity: 0;
                            transition: 0.3s;
                            position: absolute;
                            bottom: 0%;
                            border-bottom-left-radius: 5px;
                            border-bottom-right-radius: 5px;

                            visibility: hidden;
                        }

                        .bb1 {
                            position: absolute;
                            bottom: 32px;
                            left: 50%;
                        }
                        </style>
                        <div style="  " class="bb1">

                        </div>
                        <div class="s1-1">

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <script>
        var swiper = new Swiper(".mySwiper", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            loop: true,
            pagination: '.swiper-pagination',
            paginationClickable: true,
            centeredSlides: true,
            slidesPerView: 'auto',
            spaceBetween: 5,
            autoHeight: true,
            coverflowEffect: {
                rotate: 5,
                stretch: 30,
                depth: 65,
                modifier: 2,
                slideShadows: true,

            },
            pagination: {
                el: ".swiper-pagination",

            },
        });
        </script>

    </div>
</body>

</html>