<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- Stylesheets -->

    <link rel="stylesheet" href="./css/style.css">

    <link rel="stylesheet" href="./css/media.css">
    <link rel="stylesheet" href="./css/modal.css">

    <link rel="stylesheet" href="./css/slick.css">

    <link rel="stylesheet" href="./css/ken.css">


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"
        integrity="sha512-2rNj2KJ+D8s1ceNasTIex6z4HWyOnEYLVC3FigGOmyQCZc2eBXKgOxQmo3oKLHyfcj53uz4QMsRCWNbLd32Q1g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="https://unpkg.com/@popperjs/core@2/dist/umd/popper.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
</head>



<body>

    <?php include './Layout/Header.php'; ?>

    <?php include './screens/video.php';?>



    <?php include './screens/floating.php';?>

    <div id="MyContainerId2" class="bg-white">
        <lottie-player id="me" src="https://assets9.lottiefiles.com/packages/lf20_ujmcy6nw.json"
            background="transparent" speed="2" style="width: 100%; height: 100%">
        </lottie-player>
    </div>



    <div class="bg-white pt-5 mb-5 pb-5">
        <h1 class="title_concord main_section">What makes Concord Helmets stand apart?</h1>

        <p class="title_concord_desc main_section">It's Material - Fiberglass!</p>

    </div>


    <?php include './scroll.php';?>


    <div class="container-fluid bg-white pl-3 pr-3 pt-5 pb-5 logos ">
        <div class="container ">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661173162/concordassets/New_Project_1_mfnb8q.jpg"
                class="img-fluid" alt="">
            <p class="logos_read_more main_section">Read More</p>
        </div>

    </div>

    <!-- 
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 bg-white">
                    <img src="./assets/Girl.gif" alt="">
                </div>
                <div class="col-sm-6">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis, consequatur magnam
                        debitis voluptates maiores consequuntur! Ipsam illo similique iure a, ex excepturi provident
                        vero officiis delectus dicta, doloribus nam, facilis porro totam corrupti. Voluptatem explicabo
                        necessitatibus corrupti maxime delectus quae officia architecto quo alias illum repellendus
                        dignissimos at itaque praesentium nulla veritatis ab, placeat perferendis ut ipsum esse
                        excepturi tempore! Assumenda earum laboriosam nobis quis! Eaque quis odit, inventore cumque
                        veritatis placeat molestiae dolores illo et dignissimos suscipit architecto quidem consequuntur.
                        Repellendus esse aut enim delectus iusto, facere ipsum aliquam voluptatem obcaecati neque at
                        eveniet minus! Pariatur, dolore maiores vitae dolor laudantium sapiente nihil enim minus
                        temporibus maxime eaque deserunt itaque officiis, quae, autem tempore? Porro blanditiis
                        excepturi dolorem velit odio ipsum, consectetur numquam nobis iste minus magnam pariatur!
                        Deserunt asperiores molestiae fuga quis, eveniet magni minus corporis est sapiente voluptatum,
                        aut laboriosam voluptate non aliquid dolorem. Distinctio voluptatem molestiae rerum dicta
                        sapiente est? Distinctio ab fugit dicta consequuntur nesciunt quidem dolorem eaque nam cumque
                        perferendis rem, aperiam sunt quia inventore! Officia quas reprehenderit iure cum illo!
                        Necessitatibus minima placeat, dolores officiis odio iste veniam fugiat vel dolorem illum
                        veritatis voluptate et ad amet tempora, consectetur eum minus. Labore, debitis. Aut esse
                        doloribus quaerat ullam distinctio corrupti eveniet voluptatibus delectus? Repellat doloribus
                        itaque voluptas officiis modi beatae, mollitia asperiores culpa tempore totam odio consequuntur
                        ratione dolorum animi blanditiis eveniet amet, ea non rerum omnis autem deserunt vero excepturi.
                        At sed enim ullam culpa pariatur voluptates nesciunt sint debitis esse reprehenderit? Maxime vel
                        laudantium praesentium ex explicabo quisquam, tempore nostrum magnam optio sit ab sunt eum earum
                        alias reiciendis ipsum corporis dolor, voluptatum eaque doloremque, officia nesciunt suscipit
                        in? Odit ipsum minus rerum, quas iusto autem nesciunt, possimus quo neque nemo, earum maxime
                        placeat. Quis consequatur itaque facere non deleniti vero quisquam eveniet, vel odio numquam,
                        molestiae voluptas animi veniam, ex cupiditate alias aperiam totam natus! In ex nulla esse
                        explicabo? Autem magni fugiat quos eveniet dicta, eius distinctio aperiam nam ex perferendis
                        molestias obcaecati quas reiciendis alias, ipsa magnam quisquam sit, voluptatum impedit sequi
                        incidunt dolore consectetur. Consequuntur, enim. Vero dolore hic enim, accusamus non assumenda
                        autem voluptatum incidunt corporis expedita consectetur qui quis asperiores consequatur. Iure
                        labore fugit, repudiandae repellendus, nam eveniet qui neque voluptatem veritatis distinctio
                        ipsam perspiciatis repellat nobis vitae itaque nulla, hic soluta ratione suscipit! Minus nemo
                        nisi maxime, numquam doloribus facere ut odit eius placeat repudiandae possimus quis fugiat
                        accusantium aut iusto reiciendis? Magni nemo, repellat fugit eligendi voluptas tempora quis
                        reprehenderit asperiores porro totam velit libero doloremque, odio harum necessitatibus quasi
                        dolorem quae impedit suscipit in officiis cum ea eveniet! Ducimus voluptas magni natus nostrum
                        accusamus quod inventore! Aperiam quasi cupiditate libero! Sapiente illo suscipit quia, ut error
                        id commodi voluptate dolor facere minima dolorem modi facilis. Ab corrupti eum quidem fugit nisi
                        earum. Aliquid blanditiis veritatis ab illo quas temporibus quo adipisci, distinctio eos animi
                        autem, at expedita vel eius officiis sint tenetur magni facilis odit minima? Reprehenderit amet
                        veniam aspernatur veritatis est.</p>
                </div>
            </div>
        </div>
    </div> -->


    <?php include './screens/slides.php';?>




    <?php include './Layout/Footer.php';?>


    <button onclick="topFunction()" id="myBtn" title="Go to top">&#11165;</button>

    <script src="./scripts/backtop.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="  https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"
        crossorigin="anonymous"></script>

    <script type="text/javascript" src="./js/tooltip.js"></script>
    <script type="text/javascript" src="./js/ajax.js"></script>
    <script type="text/javascript" src="./js/carousel.js"></script>
    <script type="text/javascript" src="./js/slick.js"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('.carousel').slick({
            // dots: true,
            // infinite: true,
            // autoplay: true,
            // autoplaySpeed: 2000,
            // lazyLoad: 'ondemand',
            centerMode: true,
            centerPadding: '60px',
            speed: 600,
            slidesToShow: 3,
            // slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 2,
                        // slidesToScroll: 1,
                        centerMode: true,
                        centerPadding: '40px',
                        // infinite: true,
                        dots: true,

                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        // slidesToScroll: 1,
                        centerMode: true,
                        centerPadding: '40px'
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        // slidesToScroll: 1
                        centerMode: true,
                        centerPadding: '40px',
                    }
                }

            ]
        });
    });
    </script>

    <!-- lottie  -->
    <script src="https://unpkg.com/@lottiefiles/lottie-interactivity@latest/dist/lottie-interactivity.min.js"></script>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@1/dist/lottie-player.js"></script>



    <script>
    // Banner lottie
    LottieInteractivity.create({
        player: "#me",
        mode: "scroll",
        actions: [{
                visibility: [0, 1],
                type: "seek",
                frames: [1, 90]
            },

        ]
    });
    </script>
    <script>
    LottieInteractivity.create({
        player: '#me2',
        mode: 'scroll',
        actions: [{
            visibility: [0, 1],
            type: 'seek',
            frames: [1, 56],
        }, ]
    });
    </script>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script> -->


</body>

</html>