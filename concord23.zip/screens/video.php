<div class="video-wrapper bg-white">
    <video autoplay muted playsinline preload="metadata">
        <source
            src="https://res.cloudinary.com/tuskmelonimagestorage/video/upload/v1661171054/concordassets/logo_vsgxzp.mp4"
            type="video/mp4">
    </video>
</div>