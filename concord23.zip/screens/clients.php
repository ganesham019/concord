<div class="container client_position mx-auto text-center">

    <div class="client_wrap">
        <?php include './clients.svg';?>
        <!-- <img src="./assets/cl1.png" class="img-fluid" alt="">
        <img src="./assets/cl2.png" class="img-fluid" alt="">
        <img src="./assets/cl3.png" class="img-fluid" alt="">
        <img src="./assets/cl4.png" class="img-fluid" alt="">
        <img src="./assets/cl5.png" class="img-fluid" alt="">
        <img src="./assets/cl6.png" class="img-fluid" alt="">
        <img src="./assets/cl7.png" class="img-fluid" alt="">
        <img src="./assets/cl8.png" class="img-fluid" alt="">
        <img src="./assets/cl9.png" class="img-fluid" alt="">
        <img src="./assets/cl10.png" class="img-fluid" alt=""> -->
        <!-- <img src="./assets/cl11.png" class="img-fluid" alt=""> -->
        <!-- <img src="./assets/cl12.png" class="img-fluid" alt="">
        <img src="./assets/cl13.png" class="img-fluid" alt="">
        <img src="./assets/cl14.png" class="img-fluid" alt="">
        <img src="./assets/cl15.png" class="img-fluid" alt="">
        <img src="./assets/cl16.png" class="img-fluid" alt=""> -->

    </div>

</div>