<footer class="footer_section">
    <div class="footer_wrap">
        <div class="footer_wrap_item">
            <img src="./assets/Logo2.jpg" class="main_section" alt="">
            <div class="icons_foot">
                <a href="#" class=""><i class="fa fa-facebook-f"></i></a>
                <a href="#" class=""><i class="fa fa-instagram"></i></a>
                <a href="#" class=""><i class="fa fa-youtube-play"></i></a>
                <a href="#" class=""><i class="fa fa-linkedin"></i></a>
            </div>
        </div>
        <div class="footer_wrap_item2">
            <h1>Concord Helmet & Safety Products Private Limited</h1>
            <p>Factory add : 115/6-B, Devarayaneri, Asoor Post, Trichy - 620015 | CIN : U74999TN2008PT0069772
                Registered Office : #9, 10th Extension Street, Laxmi Nagar, Nanganallur, Chennai - 600061</p>
            <h6>Contact no : +91 9750996431</h6>
            <h5>© 2022 All rights reserved.</h5>
        </div>
    </div>

</footer>