<div class="video-wrapper bg-white d-none d-md-block">
    <video autoplay muted playsinline preload="metadata">
        <source
            src="https://res.cloudinary.com/tuskmelonimagestorage/video/upload/v1661248727/concordassets/Concord_Website_Logo_i7ojyb.mp4"
            type="video/mp4">
    </video>
</div>
<div class="video-wrapper bg-white d-block d-md-none">
    <video autoplay muted playsinline preload="metadata">
        <source
            src="https://res.cloudinary.com/tuskmelonimagestorage/video/upload/v1661260586/concordassets/Concord_Website_Logo_mobile_version_vjvzxg.mp4"
            type="video/mp4">
    </video>
</div>