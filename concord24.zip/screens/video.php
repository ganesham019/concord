<div class="video-wrapper bg-white d-none d-md-block">
    <video autoplay muted playsinline preload="metadata">
        <source
            src="https://res.cloudinary.com/tuskmelonimagestorage/video/upload/v1661343908/concordassets/Concord_Website_Logo_1_1_1_1_1_k2uoy8.mp4"
            type="video/mp4">
    </video>
</div>
<div class="video-wrapper bg-white d-block d-md-none">
    <video autoplay muted playsinline preload="metadata">
        <source
            src="https://res.cloudinary.com/tuskmelonimagestorage/video/upload/v1661343689/concordassets/Concord_Website_Logo_mobile_version_1_1_1_1_1_2_y5dumf.mp4"
            type="video/mp4">
    </video>
</div>