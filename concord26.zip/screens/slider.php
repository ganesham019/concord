<div class="container bg-white pt-3 pb-3 pl-1 pr-1">
    <div class="carousel">

        <div class="card " style="margin:10px;">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661342370/concordassets/s1_i2jnai.jpg"
                class="card-img-top" alt="...">
        </div>

        <div class="card " style="margin:10px;">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661342303/concordassets/Group_675_2_zxpohw.jpg"
                class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661342303/concordassets/Group_673_2_onlqdd.jpg"
                class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661342303/concordassets/Group_672_2_gmfxca.jpg"
                class="card-img-top" alt="...">
        </div>
        <div class="card " style="margin:10px;">
            <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661342303/concordassets/Group_674_2_wigwjx.jpg"
                class="card-img-top" alt="...">
        </div>

    </div>
</div>
</div>