<div class="container-fluid bg-white p-0 m-0 img_client">
    <div class="container img_client_section p-0 m-0">
        <div class="img_section">
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl10_tum3h8.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405695/concordassets/cl15_km1i9l.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl13_aptb7a.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl12_mni1cl.png"
                    class="" alt="">
            </div>
            <div class="img_set">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl14_qkf4da.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl11_c2tg7l.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405694/concordassets/cl9_hqpe8d.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405693/concordassets/cl8_efiwgn.png"
                    class="" alt="">
            </div>
            <div class="img_set">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405693/concordassets/cl3_kibzu5.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405693/concordassets/cl6_rriojg.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405693/concordassets/cl1_ceq3d1.png"
                    class="" alt="">
            </div>
            <div class="img_set">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405693/concordassets/cl4_sy2qar.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405692/concordassets/cl5_zec8pp.png"
                    class="" alt="">
            </div>
            <div class="img_set ">
                <img src="https://res.cloudinary.com/tuskmelonimagestorage/image/upload/v1661405692/concordassets/cl2_t2afaj.png"
                    class="" alt="">
            </div>
            <div class="logos_read_more ">Our Marquee Clients </div>
        </div>
    </div>
</div>